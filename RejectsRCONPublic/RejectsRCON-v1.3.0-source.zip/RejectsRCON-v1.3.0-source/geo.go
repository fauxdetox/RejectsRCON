package main

import (
	_ "embed"
	"encoding/binary"
	"net"
	"sort"
	"strings"
)

// geo.bin is DaRT's offline IP->country table, re-packed as sorted
// [start uint32][end uint32][cc 2 bytes] records. No web lookups needed.
//
//go:embed geo.bin
var geoData []byte

const geoRec = 10

func countryFor(ip string) string {
	p := net.ParseIP(ip).To4()
	if p == nil || len(geoData) < geoRec {
		return ""
	}
	v := binary.BigEndian.Uint32(p)
	n := len(geoData) / geoRec
	i := sort.Search(n, func(i int) bool {
		return binary.LittleEndian.Uint32(geoData[i*geoRec+4:]) >= v
	})
	if i >= n {
		return ""
	}
	r := geoData[i*geoRec:]
	if binary.LittleEndian.Uint32(r) <= v {
		return strings.ToUpper(string(r[8:10]))
	}
	return ""
}
