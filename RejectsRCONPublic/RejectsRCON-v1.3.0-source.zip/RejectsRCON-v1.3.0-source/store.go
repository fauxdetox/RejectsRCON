package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

type Host struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Host     string `json:"host"`
	Port     int    `json:"port"`
	Password string `json:"password"`
}

type Scheduled struct {
	ID       string `json:"id"`
	Message  string `json:"message"`
	EveryMin int    `json:"everyMin"`
	Enabled  bool   `json:"enabled"`
}

type Settings struct {
	WebPort         int         `json:"webPort"`
	OpenBrowser     bool        `json:"openBrowser"`
	RefreshSeconds  int         `json:"refreshSeconds"`
	AutoReconnect   bool        `json:"autoReconnect"`
	ConnectOnStart  string      `json:"connectOnStart"` // host id or ""
	SaveLog         bool        `json:"saveLog"`
	ConsoleBuffer   int         `json:"consoleBuffer"`
	BanReasons      []string    `json:"banReasons"`
	KickReasons     []string    `json:"kickReasons"`
	MessagePresets  []string    `json:"messagePresets"`
	Scheduled       []Scheduled `json:"scheduled"`
	RestartMessage  string      `json:"restartMessage"`
	SoundOnAdminMsg bool        `json:"soundOnAdminMsg"`
	KeepRunning     bool        `json:"keepRunning"` // false = exit when the last browser tab closes
}

func defaultSettings() Settings {
	return Settings{
		WebPort:        8723,
		OpenBrowser:    true,
		RefreshSeconds: 10,
		AutoReconnect:  true,
		SaveLog:        true,
		ConsoleBuffer:  3000,
		BanReasons:     []string{"Hacking / cheating", "Exploiting", "Griefing", "Toxicity / harassment", "Breaking server rules", "Ban evasion"},
		KickReasons:    []string{"Please rejoin", "High ping", "Restart incoming", "Breaking server rules"},
		MessagePresets: []string{"Server restart in 5 minutes - find a safe spot!", "Join our Discord for support and events."},
		RestartMessage: "Server restarting in {m} minute(s) - log out somewhere safe!",
	}
}

type NameSeen struct {
	Name string `json:"name"`
	Last string `json:"last"`
}

type Record struct {
	GUID      string     `json:"guid"`
	Names     []NameSeen `json:"names"` // most recent first
	IPs       []string   `json:"ips"`   // most recent first
	Country   string     `json:"country"`
	FirstSeen string     `json:"firstSeen"`
	LastSeen  string     `json:"lastSeen"`
	Sessions  int        `json:"sessions"`
	Note      string     `json:"note"`
	NoteDate  string     `json:"noteDate,omitempty"`
}

type Store struct {
	dir string
	mu  sync.Mutex

	settings Settings
	hosts    []Host
	players  map[string]*Record
	byIP     map[string]string // ip -> most recent guid
	dirty    bool

	logMu   sync.Mutex
	logDay  string
	logFile *os.File
}

const tsFmt = "2006-01-02 15:04:05"

func openStore(dir string) (*Store, error) {
	if err := os.MkdirAll(filepath.Join(dir, "logs"), 0o755); err != nil {
		return nil, err
	}
	s := &Store{dir: dir, players: map[string]*Record{}, byIP: map[string]string{}}
	s.settings = defaultSettings()
	if err := readJSON(filepath.Join(dir, "settings.json"), &s.settings); err != nil && !os.IsNotExist(err) {
		backup(filepath.Join(dir, "settings.json"))
	}
	if s.settings.WebPort == 0 {
		s.settings.WebPort = 8723
	}
	if s.settings.RefreshSeconds < 3 {
		s.settings.RefreshSeconds = 10
	}
	if s.settings.ConsoleBuffer < 200 {
		s.settings.ConsoleBuffer = 3000
	}
	if err := readJSON(filepath.Join(dir, "hosts.json"), &s.hosts); err != nil && !os.IsNotExist(err) {
		backup(filepath.Join(dir, "hosts.json"))
	}
	var recs []*Record
	if err := readJSON(filepath.Join(dir, "players.json"), &recs); err != nil && !os.IsNotExist(err) {
		backup(filepath.Join(dir, "players.json"))
	}
	for _, r := range recs {
		if r == nil || r.GUID == "" {
			continue
		}
		s.players[r.GUID] = r
	}
	s.reindex()
	_ = s.saveSettingsLocked()
	return s, nil
}

func backup(p string) {
	_ = os.Rename(p, p+".corrupt-"+time.Now().Format("20060102-150405"))
}

func readJSON(p string, v any) error {
	b, err := os.ReadFile(p)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}

// writeJSON writes atomically so a crash or power cut never leaves a half-written file.
func writeJSON(p string, v any) error {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, p)
}

func (s *Store) reindex() {
	s.byIP = map[string]string{}
	type pair struct{ ip, guid, last string }
	var ps []pair
	for _, r := range s.players {
		for _, ip := range r.IPs {
			ps = append(ps, pair{ip, r.GUID, r.LastSeen})
		}
	}
	sort.Slice(ps, func(i, j int) bool { return ps[i].last < ps[j].last })
	for _, p := range ps {
		s.byIP[p.ip] = p.guid
	}
}

// ---- settings / hosts ----

func (s *Store) Settings() Settings {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.settings
}

func (s *Store) SetSettings(n Settings) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if n.RefreshSeconds < 3 {
		n.RefreshSeconds = 3
	}
	if n.ConsoleBuffer < 200 {
		n.ConsoleBuffer = 200
	}
	if n.WebPort == 0 {
		n.WebPort = s.settings.WebPort
	}
	s.settings = n
	return s.saveSettingsLocked()
}

func (s *Store) saveSettingsLocked() error {
	return writeJSON(filepath.Join(s.dir, "settings.json"), s.settings)
}

func (s *Store) Hosts() []Host {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Host{}, s.hosts...)
}

func (s *Store) Host(id string) (Host, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, h := range s.hosts {
		if h.ID == id {
			return h, true
		}
	}
	return Host{}, false
}

func (s *Store) SaveHost(h Host) (Host, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	h.Host = strings.TrimSpace(h.Host)
	if h.Host == "" || h.Port <= 0 || h.Port > 65535 {
		return h, fmt.Errorf("host and a valid port are required")
	}
	if h.Name == "" {
		h.Name = fmt.Sprintf("%s:%d", h.Host, h.Port)
	}
	if h.ID == "" {
		h.ID = newID()
		s.hosts = append(s.hosts, h)
	} else {
		found := false
		for i := range s.hosts {
			if s.hosts[i].ID == h.ID {
				if h.Password == "" { // UI sends blank to mean "unchanged"
					h.Password = s.hosts[i].Password
				}
				s.hosts[i] = h
				found = true
			}
		}
		if !found {
			s.hosts = append(s.hosts, h)
		}
	}
	return h, writeJSON(filepath.Join(s.dir, "hosts.json"), s.hosts)
}

func (s *Store) DeleteHost(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := s.hosts[:0]
	for _, h := range s.hosts {
		if h.ID != id {
			out = append(out, h)
		}
	}
	s.hosts = out
	return writeJSON(filepath.Join(s.dir, "hosts.json"), s.hosts)
}

// ---- player history ----

func now() string { return time.Now().Format(tsFmt) }

// Observe records a sighting of a player. newSession=true when they just joined.
func (s *Store) Observe(guid, name, ip, country string, newSession bool) {
	if guid == "" {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	t := now()
	r := s.players[guid]
	if r == nil {
		r = &Record{GUID: guid, FirstSeen: t}
		s.players[guid] = r
		newSession = true
	}
	r.LastSeen = t
	if newSession {
		r.Sessions++
	}
	if name != "" {
		idx := -1
		for i, n := range r.Names {
			if n.Name == name {
				idx = i
			}
		}
		if idx >= 0 {
			r.Names = append(r.Names[:idx], r.Names[idx+1:]...)
		}
		r.Names = append([]NameSeen{{name, t}}, r.Names...)
		if len(r.Names) > 25 {
			r.Names = r.Names[:25]
		}
	}
	if ip != "" {
		idx := -1
		for i, x := range r.IPs {
			if x == ip {
				idx = i
			}
		}
		if idx != 0 {
			if idx > 0 {
				r.IPs = append(r.IPs[:idx], r.IPs[idx+1:]...)
			}
			r.IPs = append([]string{ip}, r.IPs...)
			if len(r.IPs) > 25 {
				r.IPs = r.IPs[:25]
			}
		}
		s.byIP[ip] = guid
		if country != "" {
			r.Country = country
		}
	}
	s.dirty = true
}

func (s *Store) Record(guid string) *Record {
	s.mu.Lock()
	defer s.mu.Unlock()
	if r := s.players[guid]; r != nil {
		c := *r
		c.Names = append([]NameSeen(nil), r.Names...)
		c.IPs = append([]string(nil), r.IPs...)
		return &c
	}
	return nil
}

func (s *Store) GUIDForIP(ip string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.byIP[ip]
}

func (s *Store) SetNote(guid, note string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	r := s.players[guid]
	if r == nil {
		r = &Record{GUID: guid, FirstSeen: now(), LastSeen: now()}
		s.players[guid] = r
	}
	r.Note = strings.TrimSpace(note)
	r.NoteDate = now()
	s.dirty = true
	return nil
}

// Search matches name (any alias), GUID, IP or note. Empty query = most recent.
func (s *Store) Search(q string, limit int) ([]Record, int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	q = strings.ToLower(strings.TrimSpace(q))
	var out []Record
	for _, r := range s.players {
		if q != "" && !matchRecord(r, q) {
			continue
		}
		out = append(out, *r)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].LastSeen > out[j].LastSeen })
	total := len(out)
	if len(out) > limit {
		out = out[:limit]
	}
	return out, total
}

func matchRecord(r *Record, q string) bool {
	if strings.Contains(r.GUID, q) || strings.Contains(strings.ToLower(r.Note), q) {
		return true
	}
	for _, n := range r.Names {
		if strings.Contains(strings.ToLower(n.Name), q) {
			return true
		}
	}
	for _, ip := range r.IPs {
		if strings.HasPrefix(ip, q) {
			return true
		}
	}
	return false
}

func (s *Store) Flush() {
	s.mu.Lock()
	if !s.dirty {
		s.mu.Unlock()
		return
	}
	recs := make([]*Record, 0, len(s.players))
	for _, r := range s.players {
		c := *r
		recs = append(recs, &c)
	}
	s.dirty = false
	s.mu.Unlock()
	sort.Slice(recs, func(i, j int) bool { return recs[i].LastSeen > recs[j].LastSeen })
	if err := writeJSON(filepath.Join(s.dir, "players.json"), recs); err != nil {
		appLog("saving players.json: %v", err)
		s.mu.Lock()
		s.dirty = true
		s.mu.Unlock()
	}
}

// ---- console log files ----

func (s *Store) LogLine(t time.Time, text string) {
	if !s.Settings().SaveLog {
		return
	}
	s.logMu.Lock()
	defer s.logMu.Unlock()
	day := t.Format("2006-01-02")
	if day != s.logDay || s.logFile == nil {
		if s.logFile != nil {
			s.logFile.Close()
		}
		f, err := os.OpenFile(filepath.Join(s.dir, "logs", day+".log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
		if err != nil {
			s.logFile = nil
			return
		}
		s.logFile, s.logDay = f, day
	}
	fmt.Fprintf(s.logFile, "%s  %s\r\n", t.Format("15:04:05"), text)
}

func (s *Store) Close() {
	s.Flush()
	s.logMu.Lock()
	if s.logFile != nil {
		s.logFile.Close()
	}
	s.logMu.Unlock()
}
