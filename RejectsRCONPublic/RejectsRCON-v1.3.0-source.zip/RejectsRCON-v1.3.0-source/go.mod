module rejectsrcon

go 1.24.7
