package main

import (
	"regexp"
	"strconv"
	"strings"
)

type Player struct {
	ID       int    `json:"id"`
	IP       string `json:"ip"`
	Port     int    `json:"port"`
	Ping     int    `json:"ping"`
	GUID     string `json:"guid"`
	Verified bool   `json:"verified"`
	Name     string `json:"name"`
	Lobby    bool   `json:"lobby"`
	Country  string `json:"country"`
	Note     string `json:"note"`
	Sessions int    `json:"sessions"`
	Aliases  int    `json:"aliases"`
}

type Ban struct {
	ID      int    `json:"id"`
	Kind    string `json:"kind"` // guid | ip
	Value   string `json:"value"`
	Minutes string `json:"minutes"` // "perm" or minutes left
	Reason  string `json:"reason"`
	Name    string `json:"name,omitempty"`
}

type Admin struct {
	ID   int    `json:"id"`
	IP   string `json:"ip"`
	Port int    `json:"port"`
}

var (
	rePlayer = regexp.MustCompile(`^(\d+)\s+([0-9.]+):(\d+)\s+(-?\d+)\s+(\S+)\s+(.*)$`)
	reGUID   = regexp.MustCompile(`^([0-9a-fA-F]{32})(?:\((OK|\?)\))?$`)
	reBan    = regexp.MustCompile(`^(\d+)\s+(\S+)\s+(perm|-?\d+|-)\s*(.*)$`)
	reAdmin  = regexp.MustCompile(`^(\d+)\s+([0-9.]+):(\d+)`)
)

func parsePlayers(s string) []Player {
	out := []Player{}
	for _, ln := range strings.Split(s, "\n") {
		ln = strings.TrimSpace(strings.TrimRight(ln, "\r"))
		m := rePlayer.FindStringSubmatch(ln)
		if m == nil {
			continue
		}
		p := Player{Name: m[6]}
		p.ID, _ = strconv.Atoi(m[1])
		p.IP = m[2]
		p.Port, _ = strconv.Atoi(m[3])
		p.Ping, _ = strconv.Atoi(m[4])
		if g := reGUID.FindStringSubmatch(m[5]); g != nil {
			p.GUID = strings.ToLower(g[1])
			p.Verified = g[2] == "OK"
		} else {
			// GUID column not there yet ("-") — the name started in field 5
			if m[5] != "-" {
				p.Name = strings.TrimSpace(m[5] + " " + m[6])
			}
		}
		if strings.HasSuffix(p.Name, " (Lobby)") {
			p.Lobby = true
			p.Name = strings.TrimSuffix(p.Name, " (Lobby)")
		}
		out = append(out, p)
	}
	return out
}

func parseBans(s string) []Ban {
	out := []Ban{}
	kind := ""
	for _, ln := range strings.Split(s, "\n") {
		ln = strings.TrimSpace(strings.TrimRight(ln, "\r"))
		low := strings.ToLower(ln)
		switch {
		case strings.HasPrefix(low, "guid bans"):
			kind = "guid"
			continue
		case strings.HasPrefix(low, "ip bans"):
			kind = "ip"
			continue
		}
		if kind == "" {
			continue
		}
		m := reBan.FindStringSubmatch(ln)
		if m == nil {
			continue
		}
		b := Ban{Kind: kind, Value: m[2], Minutes: m[3], Reason: strings.TrimSpace(m[4])}
		b.ID, _ = strconv.Atoi(m[1])
		if kind == "guid" {
			b.Value = strings.ToLower(b.Value)
		}
		out = append(out, b)
	}
	return out
}

func parseAdmins(s string) []Admin {
	out := []Admin{}
	for _, ln := range strings.Split(s, "\n") {
		m := reAdmin.FindStringSubmatch(strings.TrimSpace(ln))
		if m == nil {
			continue
		}
		a := Admin{IP: m[2]}
		a.ID, _ = strconv.Atoi(m[1])
		a.Port, _ = strconv.Atoi(m[3])
		out = append(out, a)
	}
	return out
}

// ---- server event lines ----

type Event struct {
	Kind    string // connect | guid | disconnect | kick | chat | admin | rcon | be | other
	Slot    int
	Name    string
	IP      string
	GUID    string
	Channel string
	Text    string
}

var (
	reConnect    = regexp.MustCompile(`^Player #(\d+) (.+) \(([0-9.]+):\d+\) connected$`)
	reBEGUID     = regexp.MustCompile(`^Player #(\d+) (.+) - (?:BE )?GUID: ([0-9a-fA-F]{32})$`)
	reDisconnect = regexp.MustCompile(`^Player #(\d+) (.+) disconnected$`)
	reKicked     = regexp.MustCompile(`^Player #(\d+) (.+) \(([0-9a-fA-F]{32}|-)\) has been kicked by BattlEye: (.*)$`)
	reChat       = regexp.MustCompile(`^\((Global|Side|Direct|Vehicle|Group|Command|Unknown)\) (.+?): (.*)$`)
	reAdminChat  = regexp.MustCompile(`^RCon admin #(\d+): \((\w+)\) (.*)$`)
	reAdminLogin = regexp.MustCompile(`^RCon admin #(\d+) \(([0-9.:]+)\) logged in$`)
)

func parseEvent(s string) Event {
	if m := reConnect.FindStringSubmatch(s); m != nil {
		n, _ := strconv.Atoi(m[1])
		return Event{Kind: "connect", Slot: n, Name: m[2], IP: m[3]}
	}
	if m := reBEGUID.FindStringSubmatch(s); m != nil {
		n, _ := strconv.Atoi(m[1])
		return Event{Kind: "guid", Slot: n, Name: m[2], GUID: strings.ToLower(m[3])}
	}
	if m := reKicked.FindStringSubmatch(s); m != nil {
		n, _ := strconv.Atoi(m[1])
		g := m[3]
		if g == "-" {
			g = ""
		}
		return Event{Kind: "kick", Slot: n, Name: m[2], GUID: strings.ToLower(g), Text: m[4]}
	}
	if m := reDisconnect.FindStringSubmatch(s); m != nil {
		n, _ := strconv.Atoi(m[1])
		return Event{Kind: "disconnect", Slot: n, Name: m[2]}
	}
	if m := reAdminChat.FindStringSubmatch(s); m != nil {
		return Event{Kind: "admin", Channel: m[2], Text: m[3]}
	}
	if reAdminLogin.MatchString(s) {
		return Event{Kind: "rcon", Text: s}
	}
	if m := reChat.FindStringSubmatch(s); m != nil {
		return Event{Kind: "chat", Channel: m[1], Name: m[2], Text: m[3]}
	}
	return Event{Kind: "be", Text: s}
}
