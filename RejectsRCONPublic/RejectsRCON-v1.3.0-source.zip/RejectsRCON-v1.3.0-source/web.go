package main

import (
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io/fs"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

//go:embed ui
var uiFS embed.FS

func newID() string {
	b := make([]byte, 6)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func newToken() string {
	b := make([]byte, 24)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

type server struct {
	app   *App
	st    *Store
	token string
	port  int
	quit  chan struct{}
	once  sync.Once
}

func (s *server) stop() { s.once.Do(func() { close(s.quit) }) }

func writeJSONResp(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, code int, err error) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
}

// guard: only accept requests addressed to localhost (blocks DNS rebinding) carrying this run's token (blocks other websites).
func (s *server) guard(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		host, _, _ := net.SplitHostPort(r.Host)
		if host != "127.0.0.1" && host != "localhost" {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		tok := r.Header.Get("X-Token")
		if tok == "" {
			tok = r.URL.Query().Get("token")
		}
		if tok != s.token {
			http.Error(w, "bad token - reload the page", http.StatusUnauthorized)
			return
		}
		next(w, r)
	}
}

func decode(r *http.Request, v any) error {
	defer r.Body.Close()
	return json.NewDecoder(http.MaxBytesReader(nil, r.Body, 1<<20)).Decode(v)
}

func (s *server) routes() http.Handler {
	mux := http.NewServeMux()
	sub, _ := fs.Sub(uiFS, "ui")
	index, _ := fs.ReadFile(sub, "index.html")

	mux.HandleFunc("GET /{$}", func(w http.ResponseWriter, r *http.Request) {
		host, _, _ := net.SplitHostPort(r.Host)
		if host != "127.0.0.1" && host != "localhost" {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Frame-Options", "DENY")
		page := strings.Replace(string(index), "__TOKEN__", s.token, 1)
		page = strings.Replace(page, "__VERSION__", version, 1)
		_, _ = w.Write([]byte(page))
	})
	mux.HandleFunc("GET /ping", func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("rejectsrcon\n" + s.st.dir))
	})

	mux.HandleFunc("GET /api/bootstrap", s.guard(func(w http.ResponseWriter, r *http.Request) {
		hosts := s.st.Hosts()
		for i := range hosts {
			if hosts[i].Password != "" {
				hosts[i].Password = "" // never sent to the browser
			}
		}
		writeJSONResp(w, map[string]any{
			"state":    s.app.state(),
			"hosts":    hosts,
			"settings": s.st.Settings(),
			"lines":    s.app.consoleBacklog(),
			"version":  version,
			"dataDir":  s.st.dir,
		})
	}))

	mux.HandleFunc("GET /api/events", s.guard(func(w http.ResponseWriter, r *http.Request) {
		fl, ok := w.(http.Flusher)
		if !ok {
			http.Error(w, "streaming unsupported", 500)
			return
		}
		w.Header().Set("Content-Type", "text/event-stream")
		w.Header().Set("Cache-Control", "no-store")
		ch := s.app.subscribe()
		defer s.app.unsubscribe(ch)
		ping := time.NewTicker(15 * time.Second)
		defer ping.Stop()
		fmt.Fprint(w, ": hi\n\n")
		fl.Flush()
		for {
			select {
			case <-r.Context().Done():
				return
			case <-s.quit:
				return
			case <-ping.C:
				fmt.Fprint(w, ": ping\n\n")
				fl.Flush()
			case b := <-ch:
				fmt.Fprintf(w, "data: %s\n\n", b)
				fl.Flush()
			}
		}
	}))

	post := func(path string, h func(r *http.Request) (any, error)) {
		mux.HandleFunc("POST "+path, s.guard(func(w http.ResponseWriter, r *http.Request) {
			v, err := h(r)
			if err != nil {
				fail(w, http.StatusBadRequest, err)
				return
			}
			if v == nil {
				v = map[string]bool{"ok": true}
			}
			writeJSONResp(w, v)
		}))
	}

	post("/api/connect", func(r *http.Request) (any, error) {
		var b struct{ ID string }
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.app.Connect(b.ID)
	})
	post("/api/disconnect", func(r *http.Request) (any, error) {
		s.app.Disconnect()
		return nil, nil
	})
	post("/api/host", func(r *http.Request) (any, error) {
		var h Host
		if err := decode(r, &h); err != nil {
			return nil, err
		}
		h, err := s.st.SaveHost(h)
		h.Password = ""
		return h, err
	})
	post("/api/host/delete", func(r *http.Request) (any, error) {
		var b struct{ ID string }
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.st.DeleteHost(b.ID)
	})
	post("/api/settings", func(r *http.Request) (any, error) {
		cur := s.st.Settings()
		if err := decode(r, &cur); err != nil {
			return nil, err
		}
		return s.st.Settings(), s.st.SetSettings(cur)
	})
	post("/api/raw", func(r *http.Request) (any, error) {
		var b struct{ Cmd string }
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		resp, err := s.app.Raw(b.Cmd)
		return map[string]string{"response": resp}, err
	})
	post("/api/say", func(r *http.Request) (any, error) {
		var b struct {
			Slot int
			Text string
		}
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.app.Say(b.Slot, b.Text)
	})
	post("/api/kick", func(r *http.Request) (any, error) {
		var b struct {
			GUID   string
			Slot   int
			Reason string
		}
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.app.Kick(strings.ToLower(b.GUID), b.Slot, b.Reason)
	})
	post("/api/ban", func(r *http.Request) (any, error) {
		var b struct {
			GUID    string
			Minutes int
			Reason  string
			AlsoIP  bool
		}
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.app.Ban(b.GUID, b.Minutes, b.Reason, b.AlsoIP)
	})
	post("/api/addban", func(r *http.Request) (any, error) {
		var b struct {
			Value   string
			Minutes int
			Reason  string
		}
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.app.AddBan(b.Value, b.Minutes, b.Reason)
	})
	post("/api/unban", func(r *http.Request) (any, error) {
		var b struct{ Value string }
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		return nil, s.app.Unban(b.Value)
	})
	post("/api/refresh", func(r *http.Request) (any, error) {
		var b struct{ What string }
		_ = decode(r, &b)
		return nil, s.app.RefreshNow(b.What)
	})
	post("/api/note", func(r *http.Request) (any, error) {
		var b struct{ GUID, Note string }
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		g := strings.ToLower(strings.TrimSpace(b.GUID))
		if len(g) != 32 {
			return nil, fmt.Errorf("bad GUID")
		}
		err := s.st.SetNote(g, b.Note)
		s.st.Flush()
		s.app.RefreshNow("players")
		return nil, err
	})
	post("/api/restart", func(r *http.Request) (any, error) {
		var b struct {
			Minutes  int
			Shutdown bool
			Cancel   bool
		}
		if err := decode(r, &b); err != nil {
			return nil, err
		}
		if b.Cancel {
			s.app.cancelRestart(true)
			return nil, nil
		}
		return nil, s.app.StartRestart(b.Minutes, b.Shutdown)
	})
	post("/api/quit", func(r *http.Request) (any, error) {
		go func() {
			time.Sleep(300 * time.Millisecond)
			s.stop()
		}()
		return nil, nil
	})

	mux.HandleFunc("GET /api/history", s.guard(func(w http.ResponseWriter, r *http.Request) {
		recs, total := s.st.Search(r.URL.Query().Get("q"), 300)
		if recs == nil {
			recs = []Record{}
		}
		writeJSONResp(w, map[string]any{"records": recs, "total": total})
	}))
	mux.HandleFunc("GET /api/record", s.guard(func(w http.ResponseWriter, r *http.Request) {
		rec := s.st.Record(strings.ToLower(r.URL.Query().Get("guid")))
		if rec == nil {
			fail(w, 404, fmt.Errorf("no history for that GUID"))
			return
		}
		writeJSONResp(w, rec)
	}))
	mux.HandleFunc("GET /api/logs", s.guard(func(w http.ResponseWriter, r *http.Request) {
		ents, _ := os.ReadDir(s.st.dir + string(os.PathSeparator) + "logs")
		var names []string
		for i := len(ents) - 1; i >= 0; i-- {
			if strings.HasSuffix(ents[i].Name(), ".log") {
				names = append(names, ents[i].Name())
			}
		}
		writeJSONResp(w, map[string]any{"files": names, "dir": s.st.dir})
	}))
	return mux
}
