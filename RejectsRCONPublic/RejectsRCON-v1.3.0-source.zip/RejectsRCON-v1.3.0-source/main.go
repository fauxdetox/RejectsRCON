// Rejects RCON — a BattlEye RCon admin tool for DayZ, built to replace DaRT.
// One exe, no installer. The UI runs in your browser on 127.0.0.1 only.
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
)

const version = "1.3.0"

var (
	appLogMu   sync.Mutex
	appLogPath string
)

// appLog writes the tool's own diagnostics (not server console) to data/app.log.
func appLog(format string, args ...any) {
	appLogMu.Lock()
	defer appLogMu.Unlock()
	line := time.Now().Format(tsFmt) + "  " + fmt.Sprintf(format, args...) + "\r\n"
	if appLogPath == "" {
		fmt.Fprint(os.Stderr, line)
		return
	}
	if fi, err := os.Stat(appLogPath); err == nil && fi.Size() > 2<<20 {
		_ = os.Rename(appLogPath, appLogPath+".old")
	}
	f, err := os.OpenFile(appLogPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(line)
}

func exeDir() string {
	p, err := os.Executable()
	if err != nil {
		return "."
	}
	if r, err := filepath.EvalSymlinks(p); err == nil {
		p = r
	}
	return filepath.Dir(p)
}

func main() {
	dataFlag := flag.String("data", "", "data folder (default: 'data' next to the exe)")
	noBrowser := flag.Bool("nobrowser", false, "don't open the browser on start")
	flag.Parse()

	dir := *dataFlag
	if dir == "" {
		dir = filepath.Join(exeDir(), "data")
	}
	st, err := openStore(dir)
	if err != nil {
		fatal("Could not open data folder %s: %v", dir, err)
	}
	appLogPath = filepath.Join(dir, "app.log")
	appLog("Rejects RCON %s starting, data=%s", version, dir)

	set := st.Settings()
	ln, port, err := listenFor(dir, set.WebPort)
	if err != nil {
		fatal("%v", err)
	}
	if ln == nil { // this same folder is already running: just bring it up
		openBrowser(fmt.Sprintf("http://127.0.0.1:%d/", port))
		return
	}
	if port != set.WebPort {
		// Another copy (different folder) owns the old port; remember our own from now on.
		appLog("port %d taken by another Rejects RCON copy, using %d", set.WebPort, port)
		set.WebPort = port
		_ = st.SetSettings(set)
	}
	url := fmt.Sprintf("http://127.0.0.1:%d/", port)

	app := newApp(st)
	srv := &server{app: app, st: st, token: newToken(), port: set.WebPort, quit: make(chan struct{})}
	hs := &http.Server{Handler: srv.routes(), ReadHeaderTimeout: 10 * time.Second}
	goSafe("http", func() {
		if err := hs.Serve(ln); err != nil && err != http.ErrServerClosed {
			appLog("http: %v", err)
		}
	})
	started := time.Now()
	startupWait := 2 * time.Minute
	if *noBrowser || !set.OpenBrowser {
		startupWait = 0 // launched without a browser: wait for one indefinitely
	}
	goSafe("autoexit", func() {
		for range time.Tick(2 * time.Second) {
			if app.shouldAutoExit(started, 12*time.Second, startupWait) {
				appLog("no browser tab open - closing")
				srv.stop()
				return
			}
		}
	})
	goSafe("flusher", func() {
		for range time.Tick(15 * time.Second) {
			st.Flush()
		}
	})

	app.sys("Rejects RCON %s ready. Data folder: %s", version, dir)
	if set.ConnectOnStart != "" {
		if err := app.Connect(set.ConnectOnStart); err != nil {
			app.sys("Auto-connect skipped: %v", err)
		}
	}
	if set.OpenBrowser && !*noBrowser {
		openBrowser(url)
	}
	fmt.Println("Rejects RCON running at", url)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	select {
	case <-srv.quit:
	case <-sig:
	}
	appLog("shutting down")
	app.Disconnect()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	_ = hs.Shutdown(ctx)
	st.Close()
}

// pingInstance reports whether a Rejects RCON is on port, and which data folder it uses.
func pingInstance(port int) (bool, string) {
	c := http.Client{Timeout: 2 * time.Second}
	resp, err := c.Get(fmt.Sprintf("http://127.0.0.1:%d/ping", port))
	if err != nil {
		return false, ""
	}
	defer resp.Body.Close()
	b := make([]byte, 4096)
	n, _ := io.ReadFull(resp.Body, b)
	parts := strings.SplitN(string(b[:n]), "\n", 2)
	if parts[0] != "rejectsrcon" {
		return false, ""
	}
	if len(parts) == 2 {
		return true, parts[1]
	}
	return true, ""
}

// listenFor finds the port for this data folder. Each folder = one independent instance.
// Returns ln == nil if this exact folder is already running on port.
func listenFor(dir string, want int) (net.Listener, int, error) {
	for port := want; port < want+40; port++ {
		ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", port))
		if err == nil {
			return ln, port, nil
		}
		ok, other := pingInstance(port)
		if !ok {
			if port == want {
				appLog("port %d busy (another program), trying the next one", port)
			}
			continue
		}
		if other == "" || sameDir(other, dir) {
			return nil, port, nil
		}
	}
	return nil, 0, fmt.Errorf("no free local port found between %d and %d", want, want+39)
}

func sameDir(a, b string) bool {
	ca, cb := filepath.Clean(a), filepath.Clean(b)
	if runtime.GOOS == "windows" {
		return strings.EqualFold(ca, cb)
	}
	return ca == cb
}

func fatal(format string, args ...any) {
	msg := fmt.Sprintf(format, args...)
	appLog("FATAL: %s", msg)
	showError("Rejects RCON", msg)
	os.Exit(1)
}
