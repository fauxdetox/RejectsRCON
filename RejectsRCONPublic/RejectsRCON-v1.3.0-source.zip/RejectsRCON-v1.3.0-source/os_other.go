//go:build !windows

package main

import (
	"fmt"
	"os"
	"os/exec"
)

func openBrowser(url string) { _ = exec.Command("xdg-open", url).Start() }

func showError(title, msg string) { fmt.Fprintln(os.Stderr, title+": "+msg) }
