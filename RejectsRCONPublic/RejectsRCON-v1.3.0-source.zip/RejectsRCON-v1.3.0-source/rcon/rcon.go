// Package rcon implements the BattlEye RCon protocol (v2) used by DayZ servers.
//
// Packet layout:  'B' 'E' <crc32 LE, 4 bytes> 0xFF <type> <payload...>
// The CRC covers everything from the 0xFF byte onward.
//
//	type 0x00 login      client: password            server: 0x01 ok / 0x00 bad
//	type 0x01 command    client: seq + command       server: seq + data
//	                     multipart: seq + 0x00 + total + index + data
//	type 0x02 message    server: seq + text          client must ack: seq
package rcon

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

var (
	ErrBadPassword  = errors.New("login failed: wrong RCon password")
	ErrLoginTimeout = errors.New("login timed out: no response from server (check host/port and that BattlEye RCon is enabled)")
	ErrTimeout      = errors.New("command timed out")
	ErrClosed       = errors.New("connection closed")
)

const (
	keepAliveEvery = 25 * time.Second // BE drops clients idle for 45s
	deadAfter      = 70 * time.Second // nothing received for this long = connection is dead
)

type pending struct {
	parts    [][]byte
	got      int
	total    int
	done     chan string
	progress chan struct{} // a multipart piece arrived: keep waiting
}

// Client is one logged-in RCon session. It is safe for concurrent use.
type Client struct {
	conn     *net.UDPConn
	sendMu   sync.Mutex
	mu       sync.Mutex
	seq      byte
	pending  map[byte]*pending
	lastRecv atomic.Int64
	closed   chan struct{}
	closeErr error
	once     sync.Once
	loginRes chan bool

	seenMu sync.Mutex
	seen   map[byte]seenMsg

	// Messages receives server event lines (connects, chat, kicks, ...).
	// It is buffered; if the consumer stalls, oldest-first delivery is kept by blocking briefly then dropping.
	Messages chan string
}

type seenMsg struct {
	text string
	at   time.Time
}

func packet(t byte, payload []byte) []byte {
	body := append([]byte{0xFF, t}, payload...)
	out := make([]byte, 0, 6+len(body))
	out = append(out, 'B', 'E')
	var c [4]byte
	binary.LittleEndian.PutUint32(c[:], crc32.ChecksumIEEE(body))
	out = append(out, c[:]...)
	return append(out, body...)
}

// Dial connects and logs in. The returned client keeps itself alive until Close or until the link dies (see Done).
func Dial(addr, password string, loginTimeout time.Duration) (*Client, error) {
	ua, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return nil, fmt.Errorf("bad address %q: %w", addr, err)
	}
	conn, err := net.DialUDP("udp", nil, ua)
	if err != nil {
		return nil, err
	}
	_ = conn.SetReadBuffer(1 << 20)
	c := &Client{
		conn:     conn,
		pending:  map[byte]*pending{},
		closed:   make(chan struct{}),
		loginRes: make(chan bool, 1),
		seen:     map[byte]seenMsg{},
		Messages: make(chan string, 1024),
	}
	c.lastRecv.Store(time.Now().UnixNano())
	go c.readLoop()

	// UDP can drop the login packet; retry a few times inside the timeout.
	deadline := time.After(loginTimeout)
	tick := time.NewTicker(2 * time.Second)
	defer tick.Stop()
	c.write(packet(0x00, []byte(password)))
	for {
		select {
		case ok := <-c.loginRes:
			if !ok {
				c.shutdown(ErrBadPassword)
				return nil, ErrBadPassword
			}
			go c.keepAlive()
			return c, nil
		case <-tick.C:
			c.write(packet(0x00, []byte(password)))
		case <-deadline:
			c.shutdown(ErrLoginTimeout)
			return nil, ErrLoginTimeout
		case <-c.closed:
			return nil, c.closeErr
		}
	}
}

func (c *Client) write(b []byte) error {
	c.sendMu.Lock()
	defer c.sendMu.Unlock()
	_, err := c.conn.Write(b)
	return err
}

// Done is closed when the session ends for any reason. Err tells why.
func (c *Client) Done() <-chan struct{} { return c.closed }
func (c *Client) Err() error            { return c.closeErr }

func (c *Client) Close() { c.shutdown(ErrClosed) }

func (c *Client) shutdown(err error) {
	c.once.Do(func() {
		c.closeErr = err
		close(c.closed)
		c.conn.Close()
	})
}

func (c *Client) readLoop() {
	buf := make([]byte, 65535)
	for {
		_ = c.conn.SetReadDeadline(time.Now().Add(5 * time.Second))
		n, err := c.conn.Read(buf)
		select {
		case <-c.closed:
			return
		default:
		}
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				if time.Since(time.Unix(0, c.lastRecv.Load())) > deadAfter {
					c.shutdown(errors.New("connection lost: server stopped responding"))
					return
				}
				continue
			}
			// On Windows an ICMP "port unreachable" surfaces as a read error; treat it as transient.
			if time.Since(time.Unix(0, c.lastRecv.Load())) > deadAfter {
				c.shutdown(fmt.Errorf("connection lost: %v", err))
				return
			}
			time.Sleep(200 * time.Millisecond)
			continue
		}
		c.handle(buf[:n])
	}
}

func (c *Client) handle(b []byte) {
	if len(b) < 8 || b[0] != 'B' || b[1] != 'E' || b[6] != 0xFF {
		return
	}
	if binary.LittleEndian.Uint32(b[2:6]) != crc32.ChecksumIEEE(b[6:]) {
		return
	}
	c.lastRecv.Store(time.Now().UnixNano())
	t := b[7]
	p := b[8:]
	switch t {
	case 0x00:
		if len(p) >= 1 {
			select {
			case c.loginRes <- p[0] == 0x01:
			default:
			}
		}
	case 0x01:
		if len(p) < 1 {
			return
		}
		seq := p[0]
		data := p[1:]
		c.mu.Lock()
		pd := c.pending[seq]
		if pd == nil {
			c.mu.Unlock()
			return
		}
		if len(data) >= 3 && data[0] == 0x00 { // multipart
			total, idx := int(data[1]), int(data[2])
			if total == 0 || idx >= total {
				c.mu.Unlock()
				return
			}
			if pd.parts == nil || pd.total != total {
				pd.parts = make([][]byte, total)
				pd.total = total
				pd.got = 0
			}
			if pd.parts[idx] == nil {
				pd.parts[idx] = append([]byte(nil), data[3:]...)
				pd.got++
				select {
				case pd.progress <- struct{}{}:
				default:
				}
			}
			if pd.got < pd.total {
				c.mu.Unlock()
				return
			}
			data = bytes.Join(pd.parts, nil)
		}
		delete(c.pending, seq)
		c.mu.Unlock()
		select {
		case pd.done <- string(data):
		default:
		}
	case 0x02:
		if len(p) < 1 {
			return
		}
		seq := p[0]
		_ = c.write(packet(0x02, []byte{seq})) // always ack, even duplicates
		msg := string(p[1:])
		c.seenMu.Lock()
		prev, dup := c.seen[seq]
		if dup && prev.text == msg && time.Since(prev.at) < 30*time.Second {
			c.seenMu.Unlock()
			return // server re-sent because our ack was lost
		}
		c.seen[seq] = seenMsg{msg, time.Now()}
		c.seenMu.Unlock()
		select {
		case c.Messages <- msg:
		case <-time.After(2 * time.Second):
		}
	}
}

func (c *Client) keepAlive() {
	t := time.NewTicker(keepAliveEvery)
	defer t.Stop()
	for {
		select {
		case <-c.closed:
			return
		case <-t.C:
			_, _ = c.send("", 5*time.Second, nil)
		}
	}
}

func (c *Client) send(cmd string, timeout time.Duration, carry *[][]byte) (string, error) {
	select {
	case <-c.closed:
		return "", ErrClosed
	default:
	}
	c.mu.Lock()
	seq := c.seq
	c.seq++
	pd := &pending{done: make(chan string, 1), progress: make(chan struct{}, 1)}
	if carry != nil && len(*carry) > 0 {
		// pieces received on an earlier attempt still count
		pd.parts = append([][]byte(nil), (*carry)...)
		pd.total = len(pd.parts)
		for _, x := range pd.parts {
			if x != nil {
				pd.got++
			}
		}
	}
	c.pending[seq] = pd
	c.mu.Unlock()

	if err := c.write(packet(0x01, append([]byte{seq}, []byte(cmd)...))); err != nil {
		c.mu.Lock()
		delete(c.pending, seq)
		c.mu.Unlock()
		return "", err
	}
	tm := time.NewTimer(timeout)
	defer tm.Stop()
	for {
		select {
		case s := <-pd.done:
			return s, nil
		case <-pd.progress:
			if !tm.Stop() {
				<-tm.C
			}
			tm.Reset(timeout)
		case <-tm.C:
			c.mu.Lock()
			if c.pending[seq] == pd {
				delete(c.pending, seq)
			}
			if carry != nil && pd.parts != nil {
				*carry = pd.parts
			}
			c.mu.Unlock()
			return "", ErrTimeout
		case <-c.closed:
			return "", ErrClosed
		}
	}
}

// Command sends a command and waits for the reply, retrying on packet loss.
// Commands that change state (kick/ban/say) are NOT retried, so a lost reply can't cause a double action.
func (c *Client) Command(cmd string) (string, error) {
	tries := 1
	if isReadOnly(cmd) {
		tries = 5
	}
	var err error
	var carry [][]byte
	for i := 0; i < tries; i++ {
		var s string
		s, err = c.send(cmd, 4*time.Second, &carry)
		if err == nil {
			return s, nil
		}
		if errors.Is(err, ErrClosed) {
			return "", err
		}
	}
	return "", err
}

func isReadOnly(cmd string) bool {
	f := strings.ToLower(strings.Fields(cmd + " x")[0])
	switch f {
	case "players", "bans", "admins", "x":
		return true
	}
	return false
}
