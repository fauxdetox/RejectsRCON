package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"time"

	"rejectsrcon/rcon"
)

type Line struct {
	ID      int64  `json:"id"`
	T       int64  `json:"t"` // unix ms
	Kind    string `json:"kind"`
	Channel string `json:"channel,omitempty"`
	Text    string `json:"text"`
	GUID    string `json:"guid,omitempty"`
}

type App struct {
	st *Store

	mu          sync.Mutex
	gen         int // bumps on every connect/disconnect request; stale loops exit
	client      *rcon.Client
	host        Host
	status      string // disconnected | connecting | connected | reconnecting
	statusMsg   string
	connectedAt time.Time
	players     []Player
	playersAt   time.Time
	bans        []Ban
	bansAt      time.Time
	admins      []Admin
	slotIP      map[int]string
	pollFails   int

	refreshKick chan struct{}

	lineMu  sync.Mutex
	lines   []Line
	lineSeq int64

	subMu       sync.Mutex
	subs        map[chan []byte]struct{}
	lastTabGone time.Time // when the last tab disconnected (zero while a tab is open)
	everHadTab  bool

	restartMu     sync.Mutex
	restartCancel chan struct{}
	restartEnds   time.Time

	schedMu   sync.Mutex
	schedLast map[string]time.Time
}

func newApp(st *Store) *App {
	return &App{
		st:          st,
		status:      "disconnected",
		subs:        map[chan []byte]struct{}{},
		slotIP:      map[int]string{},
		refreshKick: make(chan struct{}, 1),
		schedLast:   map[string]time.Time{},
	}
}

// goSafe runs f in a goroutine; a panic is logged instead of killing the app (DaRT's biggest problem).
func goSafe(name string, f func()) {
	go func() {
		defer func() {
			if r := recover(); r != nil {
				appLog("panic in %s: %v\n%s", name, r, debug.Stack())
			}
		}()
		f()
	}()
}

// ---------- console + push ----------

func (a *App) addLine(kind, channel, text, guid string) {
	t := time.Now()
	a.lineMu.Lock()
	a.lineSeq++
	l := Line{ID: a.lineSeq, T: t.UnixMilli(), Kind: kind, Channel: channel, Text: text, GUID: guid}
	a.lines = append(a.lines, l)
	if max := a.st.Settings().ConsoleBuffer; len(a.lines) > max {
		a.lines = append([]Line(nil), a.lines[len(a.lines)-max:]...)
	}
	a.lineMu.Unlock()
	a.st.LogLine(t, text)
	a.push("line", l)
}

func (a *App) sys(format string, args ...any) {
	a.addLine("system", "", fmt.Sprintf(format, args...), "")
}

func (a *App) push(typ string, data any) {
	b, err := json.Marshal(map[string]any{"type": typ, "data": data})
	if err != nil {
		return
	}
	a.subMu.Lock()
	for ch := range a.subs {
		select {
		case ch <- b:
		default: // slow tab: drop rather than block the app
		}
	}
	a.subMu.Unlock()
}

func (a *App) subscribe() chan []byte {
	ch := make(chan []byte, 512)
	a.subMu.Lock()
	a.subs[ch] = struct{}{}
	a.everHadTab = true
	a.lastTabGone = time.Time{}
	a.subMu.Unlock()
	return ch
}

func (a *App) unsubscribe(ch chan []byte) {
	a.subMu.Lock()
	delete(a.subs, ch)
	if len(a.subs) == 0 {
		a.lastTabGone = time.Now()
	}
	a.subMu.Unlock()
}

// ---------- state snapshot ----------

type State struct {
	Status       string   `json:"status"`
	StatusMsg    string   `json:"statusMsg"`
	Host         *Host    `json:"host"`
	ConnectedAt  int64    `json:"connectedAt"`
	Players      []Player `json:"players"`
	PlayersAt    int64    `json:"playersAt"`
	Bans         []Ban    `json:"bans"`
	BansAt       int64    `json:"bansAt"`
	Admins       []Admin  `json:"admins"`
	RestartEnds  int64    `json:"restartEnds"`
	ServerTarget string   `json:"serverTarget"`
}

func (a *App) state() State {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := State{Status: a.status, StatusMsg: a.statusMsg, Players: a.players, Bans: a.bans, Admins: a.admins}
	if a.host.ID != "" {
		h := a.host
		h.Password = ""
		s.Host = &h
		s.ServerTarget = fmt.Sprintf("%s:%d", h.Host, h.Port)
	}
	if !a.connectedAt.IsZero() {
		s.ConnectedAt = a.connectedAt.UnixMilli()
	}
	if !a.playersAt.IsZero() {
		s.PlayersAt = a.playersAt.UnixMilli()
	}
	if !a.bansAt.IsZero() {
		s.BansAt = a.bansAt.UnixMilli()
	}
	a.restartMu.Lock()
	if !a.restartEnds.IsZero() {
		s.RestartEnds = a.restartEnds.UnixMilli()
	}
	a.restartMu.Unlock()
	if s.Players == nil {
		s.Players = []Player{}
	}
	if s.Bans == nil {
		s.Bans = []Ban{}
	}
	if s.Admins == nil {
		s.Admins = []Admin{}
	}
	return s
}

func (a *App) pushState() { a.push("state", a.state()) }

func (a *App) setStatus(gen int, status, msg string) bool {
	a.mu.Lock()
	if gen != a.gen {
		a.mu.Unlock()
		return false
	}
	a.status, a.statusMsg = status, msg
	a.mu.Unlock()
	a.pushState()
	return true
}

// ---------- connection lifecycle ----------

func (a *App) Connect(hostID string) error {
	h, ok := a.st.Host(hostID)
	if !ok {
		return errors.New("unknown server profile")
	}
	a.mu.Lock()
	a.gen++
	gen := a.gen
	old := a.client
	a.client = nil
	a.host = h
	a.players, a.bans, a.admins = nil, nil, nil
	a.playersAt, a.bansAt = time.Time{}, time.Time{}
	a.connectedAt = time.Time{}
	a.status, a.statusMsg = "connecting", ""
	a.mu.Unlock()
	if old != nil {
		old.Close()
	}
	a.pushState()
	goSafe("session", func() { a.sessionLoop(gen, h) })
	return nil
}

func (a *App) Disconnect() {
	a.mu.Lock()
	a.gen++
	old := a.client
	a.client = nil
	a.status, a.statusMsg = "disconnected", ""
	a.connectedAt = time.Time{}
	a.players, a.admins = nil, nil
	a.mu.Unlock()
	if old != nil {
		old.Close()
		a.sys("Disconnected.")
	}
	a.cancelRestart(false)
	a.pushState()
}

func (a *App) current(gen int) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	return gen == a.gen
}

func (a *App) sessionLoop(gen int, h Host) {
	addr := fmt.Sprintf("%s:%d", h.Host, h.Port)
	backoff := 2 * time.Second
	first := true
	for a.current(gen) {
		if first {
			a.sys("Connecting to %s (%s)...", h.Name, addr)
		}
		c, err := rcon.Dial(addr, h.Password, 8*time.Second)
		if !a.current(gen) {
			if c != nil {
				c.Close()
			}
			return
		}
		if err != nil {
			if errors.Is(err, rcon.ErrBadPassword) {
				a.sys("%v", err)
				a.setStatus(gen, "disconnected", err.Error())
				return
			}
			if first || backoff >= 30*time.Second {
				a.sys("Could not connect: %v. Retrying...", err)
			}
			if !a.st.Settings().AutoReconnect && first {
				a.setStatus(gen, "disconnected", err.Error())
				return
			}
			a.setStatus(gen, "reconnecting", err.Error())
			first = false
			if !a.sleep(gen, backoff) {
				return
			}
			if backoff < 30*time.Second {
				backoff *= 2
			}
			continue
		}

		a.mu.Lock()
		if gen != a.gen {
			a.mu.Unlock()
			c.Close()
			return
		}
		a.client = c
		a.connectedAt = time.Now()
		a.status, a.statusMsg = "connected", ""
		a.slotIP = map[int]string{}
		a.pollFails = 0
		a.mu.Unlock()
		if first {
			a.sys("Connected!")
		} else {
			a.sys("Reconnected!")
		}
		first = false
		backoff = 2 * time.Second
		a.pushState()

		done := make(chan struct{})
		goSafe("messages", func() { a.messageLoop(gen, c, done) })
		goSafe("poller", func() { a.pollLoop(gen, c, done) })
		goSafe("initial", func() {
			a.refreshPlayers(gen, c)
			a.refreshBans(gen, c)
			a.refreshAdmins(gen, c)
		})

		<-c.Done()
		close(done)
		if !a.current(gen) {
			return
		}
		a.mu.Lock()
		a.client = nil
		a.mu.Unlock()
		if !a.st.Settings().AutoReconnect {
			a.sys("Connection lost: %v", c.Err())
			a.setStatus(gen, "disconnected", c.Err().Error())
			return
		}
		a.sys("Connection lost (%v). Reconnecting...", c.Err())
		a.setStatus(gen, "reconnecting", "connection lost")
		if !a.sleep(gen, 2*time.Second) {
			return
		}
	}
}

func (a *App) sleep(gen int, d time.Duration) bool {
	end := time.Now().Add(d)
	for time.Now().Before(end) {
		if !a.current(gen) {
			return false
		}
		time.Sleep(250 * time.Millisecond)
	}
	return a.current(gen)
}

func (a *App) messageLoop(gen int, c *rcon.Client, done chan struct{}) {
	for {
		select {
		case <-done:
			return
		case msg := <-c.Messages:
			if !a.current(gen) {
				return
			}
			a.handleEvent(msg)
		}
	}
}

func (a *App) pollLoop(gen int, c *rcon.Client, done chan struct{}) {
	tick := time.NewTimer(time.Duration(a.st.Settings().RefreshSeconds) * time.Second)
	adminTick := time.NewTicker(2 * time.Minute)
	schedTick := time.NewTicker(20 * time.Second)
	defer tick.Stop()
	defer adminTick.Stop()
	defer schedTick.Stop()
	for {
		select {
		case <-done:
			return
		case <-tick.C:
			a.refreshPlayers(gen, c)
			a.mu.Lock()
			needBans, needAdmins := a.bansAt.IsZero(), a.admins == nil
			a.mu.Unlock()
			if needBans { // first load failed (server busy / packet loss) — keep trying
				a.refreshBans(gen, c)
			}
			if needAdmins {
				a.refreshAdmins(gen, c)
			}
			tick.Reset(time.Duration(a.st.Settings().RefreshSeconds) * time.Second)
		case <-a.refreshKick:
			time.Sleep(1500 * time.Millisecond) // let the join/leave settle
			a.refreshPlayers(gen, c)
		case <-adminTick.C:
			a.refreshAdmins(gen, c)
		case <-schedTick.C:
			a.runScheduled(c)
		}
	}
}

func (a *App) requestRefresh() {
	select {
	case a.refreshKick <- struct{}{}:
	default:
	}
}

func (a *App) refreshPlayers(gen int, c *rcon.Client) error {
	resp, err := c.Command("players")
	if err != nil {
		a.mu.Lock()
		a.pollFails++
		n := a.pollFails
		a.mu.Unlock()
		if n == 3 {
			a.sys("Player list requests are timing out (server busy or restarting?)")
		}
		return err
	}
	ps := parsePlayers(resp)
	for i := range ps {
		p := &ps[i]
		p.Country = countryFor(p.IP)
		if p.GUID != "" {
			a.st.Observe(p.GUID, p.Name, p.IP, p.Country, false)
			if r := a.st.Record(p.GUID); r != nil {
				p.Note, p.Sessions, p.Aliases = r.Note, r.Sessions, len(r.Names)-1
			}
		}
	}
	a.mu.Lock()
	if gen != a.gen {
		a.mu.Unlock()
		return nil
	}
	if a.pollFails >= 3 {
		a.pollFails = 0
		a.mu.Unlock()
		a.sys("Player list is responding again.")
		a.mu.Lock()
	}
	a.pollFails = 0
	a.players = ps
	a.playersAt = time.Now()
	a.mu.Unlock()
	a.pushState()
	return nil
}

func (a *App) refreshBans(gen int, c *rcon.Client) error {
	resp, err := c.Command("bans")
	if err != nil {
		return err
	}
	bs := parseBans(resp)
	for i := range bs {
		b := &bs[i]
		g := b.Value
		if b.Kind == "ip" {
			g = a.st.GUIDForIP(b.Value)
		}
		if r := a.st.Record(g); r != nil && len(r.Names) > 0 {
			b.Name = r.Names[0].Name
		}
	}
	a.mu.Lock()
	if gen == a.gen {
		a.bans = bs
		a.bansAt = time.Now()
	}
	a.mu.Unlock()
	a.pushState()
	return nil
}

func (a *App) refreshAdmins(gen int, c *rcon.Client) error {
	resp, err := c.Command("admins")
	if err != nil {
		return err
	}
	as := parseAdmins(resp)
	a.mu.Lock()
	if gen == a.gen {
		a.admins = as
	}
	a.mu.Unlock()
	a.pushState()
	return nil
}

func (a *App) handleEvent(msg string) {
	e := parseEvent(msg)
	switch e.Kind {
	case "connect":
		a.mu.Lock()
		a.slotIP[e.Slot] = e.IP
		a.mu.Unlock()
		cc := countryFor(e.IP)
		extra := ""
		if cc != "" {
			extra = " [" + cc + "]"
		}
		if g := a.st.GUIDForIP(e.IP); g != "" {
			if r := a.st.Record(g); r != nil && len(r.Names) > 0 && r.Names[0].Name != e.Name {
				extra += fmt.Sprintf(" (IP last seen as %q)", r.Names[0].Name)
			}
		}
		a.addLine("connect", "", msg+extra, "")
		a.requestRefresh()
	case "guid":
		a.mu.Lock()
		ip := a.slotIP[e.Slot]
		a.mu.Unlock()
		cc := countryFor(ip)
		prev := a.st.Record(e.GUID)
		a.st.Observe(e.GUID, e.Name, ip, cc, true)
		text := msg
		if prev != nil {
			if len(prev.Names) > 0 && prev.Names[0].Name != e.Name {
				text += fmt.Sprintf("  (previously %q)", prev.Names[0].Name)
			}
			if prev.Note != "" {
				text += "  NOTE: " + prev.Note
			}
		} else {
			text += "  (first time seen)"
		}
		a.addLine("connect", "", text, e.GUID)
		a.checkBannedJoin(e)
	case "disconnect":
		a.addLine("connect", "", msg, "")
		a.requestRefresh()
	case "kick":
		a.addLine("kick", "", msg, e.GUID)
		a.requestRefresh()
	case "chat":
		a.addLine("chat", e.Channel, msg, "")
	case "admin":
		a.addLine("admin", e.Channel, msg, "")
	case "rcon":
		a.addLine("rcon", "", msg, "")
		a.mu.Lock()
		c := a.client
		gen := a.gen
		a.mu.Unlock()
		if c != nil {
			goSafe("admins", func() { a.refreshAdmins(gen, c) })
		}
	default:
		a.addLine("be", "", msg, "")
	}
}

// When a note says "watch", flag it loudly in the console.
func (a *App) checkBannedJoin(e Event) {
	r := a.st.Record(e.GUID)
	if r != nil && strings.Contains(strings.ToLower(r.Note), "watch") {
		a.addLine("alert", "", fmt.Sprintf("WATCHLIST: %s joined (note: %s)", e.Name, r.Note), e.GUID)
	}
}

// ---------- commands ----------

var errNotConnected = errors.New("not connected to a server")

func (a *App) cli() (*rcon.Client, int, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.client == nil || a.status != "connected" {
		return nil, 0, errNotConnected
	}
	return a.client, a.gen, nil
}

func clean(s string) string {
	s = strings.ReplaceAll(s, "\n", " ")
	s = strings.ReplaceAll(s, "\r", " ")
	return strings.TrimSpace(s)
}

func (a *App) Raw(cmd string) (string, error) {
	c, gen, err := a.cli()
	if err != nil {
		return "", err
	}
	cmd = clean(cmd)
	if cmd == "" {
		return "", errors.New("empty command")
	}
	a.addLine("cmd", "", "> "+cmd, "")
	resp, err := c.Command(cmd)
	if err != nil {
		if errors.Is(err, rcon.ErrTimeout) {
			err = errors.New("no reply from server (the command may still have run)")
		}
		a.sys("%s: %v", cmd, err)
		return "", err
	}
	if strings.TrimSpace(resp) != "" {
		a.addLine("response", "", strings.TrimRight(resp, "\n"), "")
	}
	low := strings.ToLower(strings.Fields(cmd)[0])
	switch low {
	case "kick", "ban":
		goSafe("refresh", func() { a.refreshPlayers(gen, c); a.refreshBans(gen, c) })
	case "addban", "removeban", "loadbans", "writebans":
		goSafe("refresh", func() { a.refreshBans(gen, c) })
	case "players":
		goSafe("refresh", func() { a.refreshPlayers(gen, c) })
	}
	return resp, nil
}

func (a *App) Say(slot int, text string) error {
	c, _, err := a.cli()
	if err != nil {
		return err
	}
	text = clean(text)
	if text == "" {
		return errors.New("message is empty")
	}
	if _, err := c.Command(fmt.Sprintf("say %d %s", slot, text)); err != nil {
		if !errors.Is(err, rcon.ErrTimeout) {
			return err
		}
		if _, err := c.Command(fmt.Sprintf("say %d %s", slot, text)); err != nil {
			return fmt.Errorf("message may not have been delivered: %v", err)
		}
	}
	if slot < 0 {
		a.addLine("you", "Global", "(Global) You: "+text, "")
	} else {
		a.addLine("you", "Direct", fmt.Sprintf("(To #%d %s) You: %s", slot, a.nameOfSlot(slot), text), "")
	}
	return nil
}

func (a *App) nameOfSlot(slot int) string {
	a.mu.Lock()
	defer a.mu.Unlock()
	for _, p := range a.players {
		if p.ID == slot {
			return p.Name
		}
	}
	return "?"
}

// findLive refreshes the list and returns the slot currently holding guid (or -1).
// Slots get reused as people leave/join, so we never act on a stale slot number.
func (a *App) findLive(c *rcon.Client, gen int, guid string, slot int) (Player, bool) {
	_ = a.refreshPlayers(gen, c)
	a.mu.Lock()
	defer a.mu.Unlock()
	for _, p := range a.players {
		if guid != "" && p.GUID == guid {
			return p, true
		}
		if guid == "" && p.ID == slot {
			return p, true
		}
	}
	return Player{}, false
}

// doVerified runs a state-changing command. If the reply is lost (UDP), it checks
// whether the change actually happened before deciding, and only then retries once.
// This avoids both false "failed" errors and double actions.
func (a *App) doVerified(c *rcon.Client, cmd string, happened func() bool, retryCmd func() (string, bool)) error {
	_, err := c.Command(cmd)
	if err == nil || !errors.Is(err, rcon.ErrTimeout) {
		return err
	}
	if happened() {
		return nil
	}
	next, ok := retryCmd()
	if !ok {
		return nil // target is gone; nothing left to do
	}
	_, err = c.Command(next)
	if err != nil && errors.Is(err, rcon.ErrTimeout) && happened() {
		return nil
	}
	if err != nil {
		return fmt.Errorf("no reply from server (%v) - check the list before trying again", err)
	}
	return nil
}

func (a *App) guidOnline(gen int, c *rcon.Client, guid string) (Player, bool) {
	_ = a.refreshPlayers(gen, c)
	a.mu.Lock()
	defer a.mu.Unlock()
	for _, p := range a.players {
		if p.GUID == guid {
			return p, true
		}
	}
	return Player{}, false
}

func (a *App) banListed(gen int, c *rcon.Client, value string) bool {
	if err := a.refreshBans(gen, c); err != nil {
		return false
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	for _, b := range a.bans {
		if b.Value == value {
			return true
		}
	}
	return false
}

func (a *App) Kick(guid string, slot int, reason string) error {
	c, gen, err := a.cli()
	if err != nil {
		return err
	}
	p, ok := a.findLive(c, gen, guid, slot)
	if !ok {
		return errors.New("that player is no longer on the server")
	}
	reason = clean(reason)
	kickCmd := func(id int) string { return strings.TrimSpace(fmt.Sprintf("kick %d %s", id, reason)) }
	var err2 error
	if p.GUID != "" {
		err2 = a.doVerified(c, kickCmd(p.ID),
			func() bool { _, on := a.guidOnline(gen, c, p.GUID); return !on },
			func() (string, bool) { q, on := a.guidOnline(gen, c, p.GUID); return kickCmd(q.ID), on })
	} else {
		_, err2 = c.Command(kickCmd(p.ID)) // no GUID yet: can't verify, don't retry
	}
	if err2 != nil {
		return err2
	}
	a.addLine("you", "", fmt.Sprintf("You kicked %s (%s)", p.Name, orDash(reason)), p.GUID)
	goSafe("refresh", func() { a.requestRefresh() })
	return nil
}

func orDash(s string) string {
	if s == "" {
		return "no reason"
	}
	return s
}

func durText(min int) string {
	if min <= 0 {
		return "permanent"
	}
	switch {
	case min%1440 == 0:
		return fmt.Sprintf("%dd", min/1440)
	case min%60 == 0:
		return fmt.Sprintf("%dh", min/60)
	}
	return fmt.Sprintf("%dm", min)
}

// Ban bans by GUID (online or offline). alsoIP adds an IP ban for their latest IP.
func (a *App) Ban(guid string, minutes int, reason string, alsoIP bool) error {
	c, gen, err := a.cli()
	if err != nil {
		return err
	}
	guid = strings.ToLower(strings.TrimSpace(guid))
	if len(guid) != 32 {
		return errors.New("a 32-character BE GUID is required")
	}
	if minutes < 0 {
		minutes = 0
	}
	reason = clean(reason)
	name := guid[:8]
	ip := ""
	if r := a.st.Record(guid); r != nil {
		if len(r.Names) > 0 {
			name = r.Names[0].Name
		}
		if len(r.IPs) > 0 {
			ip = r.IPs[0]
		}
	}
	p, online := a.findLive(c, gen, guid, -1)
	addCmd := strings.TrimSpace(fmt.Sprintf("addBan %s %d %s", guid, minutes, reason))
	listed := func() bool { return a.banListed(gen, c, guid) }
	if online {
		ip = p.IP
		banCmd := strings.TrimSpace(fmt.Sprintf("ban %d %d %s", p.ID, minutes, reason))
		if err := a.doVerified(c, banCmd, listed, func() (string, bool) { return addCmd, true }); err != nil {
			return err
		}
		// "ban" also kicks; if they're somehow still on (lost packet), kick them now
		if q, on := a.guidOnline(gen, c, guid); on {
			_, _ = c.Command(strings.TrimSpace(fmt.Sprintf("kick %d %s", q.ID, reason)))
		}
	} else {
		if err := a.doVerified(c, addCmd, listed, func() (string, bool) { return addCmd, true }); err != nil {
			return err
		}
	}
	msg := fmt.Sprintf("You banned %s (%s, %s)", name, durText(minutes), orDash(reason))
	if alsoIP && ip != "" {
		ipCmd := strings.TrimSpace(fmt.Sprintf("addBan %s %d %s", ip, minutes, reason))
		if err := a.doVerified(c, ipCmd, func() bool { return a.banListed(gen, c, ip) }, func() (string, bool) { return ipCmd, true }); err != nil {
			a.sys("GUID ban done, but IP ban failed: %v", err)
		} else {
			msg += " + IP " + ip
		}
	}
	a.addLine("you", "", msg, guid)
	goSafe("refresh", func() { time.Sleep(500 * time.Millisecond); a.refreshBans(gen, c); a.refreshPlayers(gen, c) })
	return nil
}

func (a *App) AddBan(value string, minutes int, reason string) error {
	value = strings.ToLower(strings.TrimSpace(value))
	if len(value) == 32 && !strings.Contains(value, ".") {
		return a.Ban(value, minutes, reason, false)
	}
	c, gen, err := a.cli()
	if err != nil {
		return err
	}
	if strings.Count(value, ".") != 3 {
		return errors.New("enter a 32-char GUID or an IPv4 address")
	}
	reason = clean(reason)
	ipCmd := strings.TrimSpace(fmt.Sprintf("addBan %s %d %s", value, minutes, reason))
	if err := a.doVerified(c, ipCmd, func() bool { return a.banListed(gen, c, value) }, func() (string, bool) { return ipCmd, true }); err != nil {
		return err
	}
	a.addLine("you", "", fmt.Sprintf("You banned IP %s (%s, %s)", value, durText(minutes), orDash(reason)), "")
	goSafe("refresh", func() { a.refreshBans(gen, c) })
	return nil
}

// Unban looks the ban up fresh by value right before removing, because BE renumbers bans after every removal.
func (a *App) Unban(value string) error {
	c, gen, err := a.cli()
	if err != nil {
		return err
	}
	value = strings.ToLower(strings.TrimSpace(value))
	if err := a.refreshBans(gen, c); err != nil {
		if err = a.refreshBans(gen, c); err != nil {
			return fmt.Errorf("could not read ban list: %w", err)
		}
	}
	a.mu.Lock()
	id := -1
	for _, b := range a.bans {
		if b.Value == value {
			id = b.ID
			break
		}
	}
	a.mu.Unlock()
	if id < 0 {
		return errors.New("ban not found (already removed?)")
	}
	gone := func() bool { return !a.banListed(gen, c, value) }
	retry := func() (string, bool) { // ids shift, so look it up again
		a.mu.Lock()
		defer a.mu.Unlock()
		for _, b := range a.bans {
			if b.Value == value {
				return "removeBan " + strconv.Itoa(b.ID), true
			}
		}
		return "", false
	}
	if err := a.doVerified(c, "removeBan "+strconv.Itoa(id), gone, retry); err != nil {
		return err
	}
	_, _ = c.Command("writeBans")
	a.addLine("you", "", "You removed the ban on "+value, "")
	goSafe("refresh", func() { a.refreshBans(gen, c) })
	return nil
}

func (a *App) RefreshNow(what string) error {
	c, gen, err := a.cli()
	if err != nil {
		return err
	}
	switch what {
	case "bans":
		return a.refreshBans(gen, c)
	case "admins":
		return a.refreshAdmins(gen, c)
	default:
		return a.refreshPlayers(gen, c)
	}
}

// ---------- restart countdown + scheduled messages ----------

func (a *App) StartRestart(minutes int, shutdown bool) error {
	c, _, err := a.cli()
	if err != nil {
		return err
	}
	if minutes < 1 || minutes > 120 {
		return errors.New("minutes must be 1-120")
	}
	a.cancelRestart(false)
	cancel := make(chan struct{})
	a.restartMu.Lock()
	a.restartCancel = cancel
	a.restartEnds = time.Now().Add(time.Duration(minutes) * time.Minute)
	end := a.restartEnds
	a.restartMu.Unlock()
	a.pushState()
	what := "warnings only"
	if shutdown {
		what = "then #shutdown"
	}
	a.sys("Restart countdown started: %d min, %s.", minutes, what)

	marks := map[int]bool{60: true, 30: true, 15: true, 10: true, 5: true, 3: true, 2: true, 1: true}
	marks[minutes] = true
	goSafe("restart", func() {
		said := map[int]bool{}
		for {
			left := time.Until(end)
			m := int((left + 59*time.Second) / time.Minute)
			if left <= 0 {
				break
			}
			if marks[m] && !said[m] && left <= time.Duration(m)*time.Minute+time.Second {
				said[m] = true
				msg := strings.ReplaceAll(a.st.Settings().RestartMessage, "{m}", strconv.Itoa(m))
				if _, err := c.Command("say -1 " + clean(msg)); err == nil {
					a.addLine("you", "Global", "(Global) You: "+msg, "")
				}
			}
			select {
			case <-cancel:
				return
			case <-time.After(time.Second):
			}
		}
		a.restartMu.Lock()
		a.restartEnds = time.Time{}
		a.restartCancel = nil
		a.restartMu.Unlock()
		if shutdown {
			if cc, _, err := a.cli(); err == nil {
				a.addLine("cmd", "", "> #shutdown", "")
				_, _ = cc.Command("#shutdown")
			}
		} else {
			a.sys("Restart countdown finished.")
		}
		a.pushState()
	})
	return nil
}

func (a *App) cancelRestart(announce bool) {
	a.restartMu.Lock()
	ch := a.restartCancel
	a.restartCancel = nil
	a.restartEnds = time.Time{}
	a.restartMu.Unlock()
	if ch != nil {
		close(ch)
		if announce {
			a.sys("Restart countdown cancelled.")
		}
		a.pushState()
	}
}

func (a *App) runScheduled(c *rcon.Client) {
	s := a.st.Settings()
	a.schedMu.Lock()
	defer a.schedMu.Unlock()
	for _, m := range s.Scheduled {
		if !m.Enabled || m.EveryMin < 1 || strings.TrimSpace(m.Message) == "" {
			continue
		}
		last, ok := a.schedLast[m.ID]
		if !ok {
			a.schedLast[m.ID] = time.Now() // first run waits one full interval
			continue
		}
		if time.Since(last) >= time.Duration(m.EveryMin)*time.Minute {
			a.schedLast[m.ID] = time.Now()
			if _, err := c.Command("say -1 " + clean(m.Message)); err == nil {
				a.addLine("you", "Global", "(Global) Scheduled: "+clean(m.Message), "")
			}
		}
	}
}

func (a *App) consoleBacklog() []Line {
	a.lineMu.Lock()
	defer a.lineMu.Unlock()
	return append([]Line(nil), a.lines...)
}

// shouldAutoExit: no tab open for `grace` (a page reload reconnects within a second or two),
// and no restart countdown is running (it must stay alive to send the warnings / #shutdown).
func (a *App) shouldAutoExit(started time.Time, grace, startupWait time.Duration) bool {
	if a.st.Settings().KeepRunning {
		return false
	}
	a.restartMu.Lock()
	countdown := !a.restartEnds.IsZero()
	a.restartMu.Unlock()
	if countdown {
		return false
	}
	a.subMu.Lock()
	defer a.subMu.Unlock()
	if len(a.subs) > 0 {
		return false
	}
	if !a.everHadTab {
		return startupWait > 0 && time.Since(started) > startupWait // browser never showed up
	}
	return !a.lastTabGone.IsZero() && time.Since(a.lastTabGone) > grace
}
