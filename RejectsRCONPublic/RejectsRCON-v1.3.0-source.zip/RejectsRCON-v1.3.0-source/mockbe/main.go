// mockbe is a fake BattlEye RCon server for testing. Not shipped.
package main

import (
	"encoding/binary"
	"flag"
	"fmt"
	"hash/crc32"
	"log"
	"math/rand"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"
)

type pl struct {
	name, ip, guid string
	ping           int
}
type ban struct{ val, min, reason string }

var (
	mu      sync.Mutex
	players = map[int]*pl{}
	guidBan []ban
	ipBan   []ban
	client  *net.UDPAddr
	msgSeq  byte
	conn    *net.UDPConn
	drop    float64
)

func pkt(t byte, p []byte) []byte {
	body := append([]byte{0xFF, t}, p...)
	b := []byte{'B', 'E', 0, 0, 0, 0}
	binary.LittleEndian.PutUint32(b[2:], crc32.ChecksumIEEE(body))
	return append(b, body...)
}

func send(b []byte) {
	if rand.Float64() < drop {
		return
	}
	if client != nil {
		conn.WriteToUDP(b, client)
	}
}

func serverMsg(s string) {
	mu.Lock()
	seq := msgSeq
	msgSeq++
	mu.Unlock()
	send(pkt(0x02, append([]byte{seq}, s...)))
}

func playersText() string {
	var sb strings.Builder
	sb.WriteString("Players on server:\n[#] [IP Address]:[Port] [Ping] [GUID] [Name]\n--------------------------------------------------\n")
	for i := 0; i < 64; i++ {
		p := players[i]
		if p == nil {
			continue
		}
		g := p.guid + "(OK)"
		if p.guid == "" {
			g = "-"
		}
		fmt.Fprintf(&sb, "%-3d %s:2304     %-4d %s %s\n", i, p.ip, p.ping, g, p.name)
	}
	fmt.Fprintf(&sb, "(%d players in total)", len(players))
	return sb.String()
}

func bansText() string {
	var sb strings.Builder
	sb.WriteString("GUID Bans:\n[#] [GUID] [Minutes left] [Reason]\n----------------------------------------\n")
	for i, b := range guidBan {
		fmt.Fprintf(&sb, "%-3d %s %s %s\n", i, b.val, b.min, b.reason)
	}
	sb.WriteString("\nIP Bans:\n[#] [IP Address] [Minutes left] [Reason]\n----------------------------------------------\n")
	for i, b := range ipBan {
		fmt.Fprintf(&sb, "%-3d %-15s %s %s\n", len(guidBan)+i, b.val, b.min, b.reason)
	}
	return sb.String()
}

func reply(seq byte, s string) {
	const chunk = 1000
	if len(s) <= chunk {
		send(pkt(0x01, append([]byte{seq}, s...)))
		return
	}
	n := (len(s) + chunk - 1) / chunk
	for i := 0; i < n; i++ {
		end := (i + 1) * chunk
		if end > len(s) {
			end = len(s)
		}
		send(pkt(0x01, append([]byte{seq, 0x00, byte(n), byte(i)}, s[i*chunk:end]...)))
	}
}

func handleCmd(seq byte, cmd string) {
	mu.Lock()
	defer mu.Unlock()
	f := strings.Fields(cmd)
	if len(f) == 0 {
		reply(seq, "")
		return
	}
	switch strings.ToLower(f[0]) {
	case "players":
		reply(seq, playersText())
	case "bans":
		reply(seq, bansText())
	case "admins":
		reply(seq, "Connected RCon admins:\n[#] [IP Address]:[Port]\n-----------------------------\n0   127.0.0.1:50000\n")
	case "kick":
		id, _ := strconv.Atoi(f[1])
		if p := players[id]; p != nil {
			delete(players, id)
			go serverMsg(fmt.Sprintf("Player #%d %s (%s) has been kicked by BattlEye: Admin Kick (%s)", id, p.name, p.guid, strings.Join(f[2:], " ")))
		}
		reply(seq, "")
	case "ban":
		id, _ := strconv.Atoi(f[1])
		if p := players[id]; p != nil {
			m := f[2]
			if m == "0" {
				m = "perm"
			}
			guidBan = append(guidBan, ban{p.guid, m, strings.Join(f[3:], " ")})
			delete(players, id)
			go serverMsg(fmt.Sprintf("Player #%d %s (%s) has been kicked by BattlEye: Admin Ban (%s)", id, p.name, p.guid, strings.Join(f[3:], " ")))
		}
		reply(seq, "")
	case "addban":
		m := f[2]
		if m == "0" {
			m = "perm"
		}
		b := ban{f[1], m, strings.Join(f[3:], " ")}
		if strings.Contains(f[1], ".") {
			ipBan = append(ipBan, b)
		} else {
			guidBan = append(guidBan, b)
		}
		reply(seq, "")
	case "removeban":
		id, _ := strconv.Atoi(f[1])
		if id < len(guidBan) {
			guidBan = append(guidBan[:id], guidBan[id+1:]...)
		} else if id-len(guidBan) < len(ipBan) {
			j := id - len(guidBan)
			ipBan = append(ipBan[:j], ipBan[j+1:]...)
		}
		reply(seq, "")
	case "say":
		reply(seq, "")
		go serverMsg("RCon admin #0: (" + map[bool]string{true: "Global", false: "Direct"}[f[1] == "-1"] + ") " + strings.Join(f[2:], " "))
	default:
		reply(seq, "")
	}
}

func randGUID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return fmt.Sprintf("%x", b)
}

func simulate() {
	names := []string{"jsrhJSZMTG8", "2ebcJtEm itk3t", "ubZZ9Bvt", "0geaHaX1fE", "1cpzBB25", "30CxdSpSO8GGg", "vBoIx8BJaZp", "YB353AYi", "tEE cj4jBp8e"}
	guids := map[string]string{"jsrhJSZMTG8": "36e86ba872119258ccabd087475fd9fa", "2ebcJtEm itk3t": "95a507256c223fadb74e2ec3cc7b4714"}
	for {
		time.Sleep(time.Duration(800+rand.Intn(1500)) * time.Millisecond)
		mu.Lock()
		r := rand.Float64()
		if (r < 0.5 && len(players) < 7) || len(players) < 3 {
			slot := 0
			for players[slot] != nil {
				slot++
			}
			n := names[rand.Intn(len(names))]
			g := guids[n]
			if g == "" {
				g = randGUID()
				guids[n] = g
			}
			ip := fmt.Sprintf("%d.%d.%d.%d", 24+rand.Intn(180), rand.Intn(255), rand.Intn(255), 1+rand.Intn(250))
			if n == "2ebcJtEm itk3t" {
				ip = "192.168.167.153"
			}
			players[slot] = &pl{n, ip, g, 20 + rand.Intn(220)}
			mu.Unlock()
			serverMsg(fmt.Sprintf("Player #%d %s (%s:2304) connected", slot, n, ip))
			serverMsg(fmt.Sprintf("Player #%d %s - BE GUID: %s", slot, n, g))
			continue
		}
		if r < 0.75 && len(players) > 0 {
			for id, p := range players {
				delete(players, id)
				mu.Unlock()
				serverMsg(fmt.Sprintf("Player #%d %s disconnected", id, p.name))
				break
			}
			continue
		}
		var who string
		for _, p := range players {
			who = p.name
			break
		}
		mu.Unlock()
		if who != "" {
			serverMsg(fmt.Sprintf("(Global) %s: anyone near Berezino? need a car", who))
		}
	}
}

func main() {
	addr := flag.String("addr", "127.0.0.1:2306", "")
	pw := flag.String("pw", "test", "")
	flag.Float64Var(&drop, "drop", 0.1, "packet drop rate")
	nb := flag.Int("bans", 120, "seed bans (forces multipart)")
	flag.Parse()
	for i := 0; i < *nb; i++ {
		guidBan = append(guidBan, ban{randGUID(), "perm", fmt.Sprintf("Cheating #%d", i)})
	}
	guidBan = append(guidBan, ban{"95a507256c223fadb74e2ec3cc7b4714", "1440", "Toxic in chat"})
	ipBan = append(ipBan, ban{"10.193.200.243", "perm", "VPN abuse"})
	ua, _ := net.ResolveUDPAddr("udp", *addr)
	var err error
	conn, err = net.ListenUDP("udp", ua)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("mock BE on %s drop=%.2f", *addr, drop)
	go simulate()
	buf := make([]byte, 4096)
	for {
		n, from, err := conn.ReadFromUDP(buf)
		if err != nil {
			continue
		}
		if rand.Float64() < drop {
			continue
		}
		b := buf[:n]
		if n < 8 || binary.LittleEndian.Uint32(b[2:6]) != crc32.ChecksumIEEE(b[6:]) {
			continue
		}
		t, p := b[7], b[8:]
		switch t {
		case 0x00:
			client = from
			ok := byte(0)
			if string(p) == *pw {
				ok = 1
			}
			send(pkt(0x00, []byte{ok}))
		case 0x01:
			if from.String() != client.String() {
				continue
			}
			handleCmd(p[0], string(p[1:]))
		case 0x02: // ack
		}
	}
}
